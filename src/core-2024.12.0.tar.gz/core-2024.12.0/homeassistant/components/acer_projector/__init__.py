"""The acer_projector component."""
