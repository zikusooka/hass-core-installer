"""Constants for the AirVisual Pro integration."""

import logging

DOMAIN = "airvisual_pro"

LOGGER = logging.getLogger(__package__)
