"""Constants for the Airtouch 5 integration."""

DOMAIN = "airtouch5"

FAN_TURBO = "turbo"
FAN_INTELLIGENT_AUTO = "intelligent_auto"
