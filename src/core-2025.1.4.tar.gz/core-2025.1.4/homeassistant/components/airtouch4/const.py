"""Constants for the AirTouch4 integration."""

DOMAIN = "airtouch4"
