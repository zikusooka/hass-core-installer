"""Backports from newer Python versions."""
