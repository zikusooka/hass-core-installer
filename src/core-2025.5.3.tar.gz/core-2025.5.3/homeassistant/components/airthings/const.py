"""Constants for the Airthings integration."""

DOMAIN = "airthings"

CONF_SECRET = "secret"
