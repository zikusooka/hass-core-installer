"""Constants for the air_quality entity platform."""

from typing import Final

DOMAIN: Final = "air_quality"
