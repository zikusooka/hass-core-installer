"""Constants for component."""

DOMAIN = "acaia"
CONF_IS_NEW_STYLE_SCALE = "is_new_style_scale"
