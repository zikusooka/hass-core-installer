"""Noise suppression and auto gain with speex."""
from speex_noise_cpp import AudioProcessor  # pylint: disable=E0611

__all__ = ["AudioProcessor"]
